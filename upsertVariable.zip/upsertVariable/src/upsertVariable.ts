#!/usr/bin/env node
const ado_url = 'https://dev.azure.com/AADevOpsDemo';
const bearer_token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Im9PdmN6NU1fN3AtSGpJS2xGWHo5M3VfVjBabyJ9.eyJuYW1laWQiOiJhZmI3OGZlNS02NTRmLTRiYWYtOGQ3YS03YmJkNTUxYzE3MjQiLCJzY3AiOiJhcHBfdG9rZW4iLCJhdWkiOiI1ZDhiN2Y0YS1hMTM5LTQwZDAtYjQ4ZC1lZTE0ODQzZjZiMGMiLCJzaWQiOiJjNzM1Mjk1NS0zYWUzLTRkNDQtODcxYS1jZGMwOWY2NWQ0ZmMiLCJpc3MiOiJhcHAudnN0b2tlbi52aXN1YWxzdHVkaW8uY29tIiwiYXVkIjoiYXBwLnZzdG9rZW4udmlzdWFsc3R1ZGlvLmNvbXx2c286NjVkMzZmYjEtNDRmZi00YjhkLWIwMzgtODQ4NGJlYzU4ZGE4IiwibmJmIjoxNjU3NTQwNjE5LCJleHAiOjE2NTc1NDQ4MTl9.Au5hVNS2gyviMxo6B5rPWLdAHXpRaQP0NQu8UOrtX4ULaD9DY4iJgm60eXIhPgmjQMa9V5-Q72rzmMxguhOg6YPQ-qccQmih0ra6PQOzfa4AzcpnN9Wspb_Gb4eNPpDpqQ1_c_4e9P8V1xCyWoDSqKxcBkuorzog44UJSKuD2MZGNNRNMNdAUOxl89wdNEQ_yfFD03meu6tu2BqZOgQGt98iS_dEySRj2yvVYyvjm3xlrvuVgnp8KrV-sRnaIf_9S8MM1XOxN6M67xJIZubn0NdY68KOHOA3oU5zWF9mj7kT0VCC8P1e66YBUpu9yLnTEXksenPfYfeU_NVRWScpYg';
const http_proxy = '';

const argv = require('yargs')
    .usage('Usage: $0 [options] \n')
    .options({
      variablegroup: {
        type: 'string',
        alias: 'g',
        describe: 'Name of Variable Group in Library',
        default: '' },
      projs: {
        type: 'string',
        alias: 'p',
        describe: 'ALL: Upsert all projects in tsmcit \n proj1,proj2,proj3: Upset proj1,proj2,proj3 in tsmcit',
        default: '' },
      overwrtie: {
        type: 'boolean',
        alias: 'o',
        describe: 'true: Overwaite variable group \n false: No overwaite variable group',
        default: true },
      keyvalue: {
        type: 'string',
        alias: 'k',
        describe: 'json array format',
        default: '' }
      }).help().alias('help', 'h').alias('version', 'v').argv;

upsertVariable(argv.variablegroup, argv.projs, argv.overwrtie, argv.keyvalue);

function upsertVariable(variablegroup:string, projs:string, overwrtie:boolean, keyvalue:string) {
  if (variablegroup == '' || projs == '' || keyvalue == '') {
    console.log('Variable Group, Project or Variable is empty.')
    return;
  }

  let querystring = require('querystring');
  let url = require('url');
  let https = require('https');
  let HttpProxyAgent = require('http-proxy-agent');
  let respjbody = '';
  let resvgbody = '';
  // HTTP/HTTPS proxy to connect to
  let proxy = process.env.http_proxy || http_proxy;

  console.log('[Using Proxy Server]: %j', proxy);
  console.log('[Azure DevOps Url]: %j', ado_url);
  console.log('[Variable Group Name]: %j', variablegroup);
  console.log('[Project Teams List]: %j', projs);
  console.log('[Overwrtie]: %j', overwrtie);
  console.log('[Key and Value]: %j\n', keyvalue);

  let headerDict = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'authorization': 'Bearer ' + bearer_token
  };

  console.log('\nStep1. Get team project list.');
  let pjsopts = url.parse(ado_url + '/_apis/projects?api-version=6.0');
  console.log('Get Projects Url: ' + pjsopts.href);
  pjsopts.headers = headerDict;
  if (proxy != '') {
    // create an instance of the `HttpProxyAgent` class with the proxy server information
    let agent = new HttpProxyAgent(proxy);
    pjsopts.agent = agent;
  }

  // Step1. Get Team Projects in Organization
  https.get(pjsopts, function(response: { on: (arg0: string, arg1: { (response: any): void; (string: any): void; }) => void; }) {       
    response.on('data', function(response) {
      respjbody += response.toString();
    });

    response.on('end', function(string) {
      let pjsobj = JSON.parse(respjbody);
      respjbody = '';

      console.log('Project Count: ' + pjsobj.count);
      for (let i = 0; i < pjsobj.count; i++) {
        let projlist = projs.toLowerCase().split(',').map(element => element.trim());;
        if (projs.toLowerCase() == 'all' || projlist.includes(pjsobj.value[i].name.toLowerCase())) {
          let prjname = pjsobj.value[i].name;
          let prjid = pjsobj.value[i].id;
          console.log('Project - [' + prjname + ']: ' + prjid);

          // Step2. Get Variable Groups in Team Project
          console.log('\nStep2.' + i + ' Get variable groups in team projects.');
          let vgsopts = url.parse(ado_url + '/' + prjid + '/_apis/distributedtask/variablegroups?api-version=6.0-preview.2');
          console.log('Get Variable Groups Url: ' + vgsopts.href);
          vgsopts.headers = headerDict;
          if (proxy != '') {
            // create an instance of the `HttpProxyAgent` class with the proxy server information
            let agent = new HttpProxyAgent(proxy);
            vgsopts.agent = agent;
          }
      
          https.get(vgsopts, function(response: { on: (arg0: string, arg1: { (response: any): void; (string: any): void; }) => void; }) {       
            response.on('data', function(response) {
              resvgbody += response.toString();
            });

            response.on('end', function(string) {
              let vgsobj = JSON.parse(resvgbody);
              resvgbody = '';

              if (vgsobj.count > 0) {
                for (let j = 0; j < vgsobj.count; j++) {
                  if (vgsobj.value[j].name.toLowerCase() == variablegroup.toLowerCase())
                  {
                    let vgname = vgsobj.value[j].name;
                    let vgid = vgsobj.value[j].id;
                    
                    console.log('\nStep3.' + j + ' Upsert variable in variable groups.');
                    console.log('[' + prjname + ']-Variable Group Count: ' + vgsobj.count);
                    console.log('[' + prjname + ']-Variable Group [' + vgname + '] ID: ' + vgid);
                    console.log(vgsobj.value[j].variables);

                    // Step3. Upset Variable to Variable Group
                    let varsobj = vgsobj.value[j].variables
                    let keyvalueobj = JSON.parse(keyvalue);
                    for (let key in keyvalueobj) {
                      if (key in varsobj && !overwrtie) {
                        // No overwrite
                        console.log('No overwrite');
                      }
                      else {
                        varsobj[key] = keyvalueobj[key];
                      }
                    }

                    let putdata = '{"name":"' + vgname + '","variables":' + JSON.stringify(varsobj) + '}';
                    let putheaderDict = {
                      'Content-Type': 'application/json',
                      'Accept': 'application/json',
                      'Content-Length': Buffer.byteLength(putdata),
                      'authorization': 'Bearer ' + bearer_token
                    }

                    let usvopts = url.parse(ado_url + '/' + prjid + '/_apis/distributedtask/variablegroups/' + vgid + '?api-version=5.0-preview.1');
                    console.log('Upsert Variable Url: ' + usvopts.href);
                    console.log('[' + prjname + '-Upsert Variable Body]:' + putdata);
                    usvopts.method = 'PUT';
                    usvopts.headers = putheaderDict;
                    if (proxy != '') {
                      // create an instance of the `HttpProxyAgent` class with the proxy server information
                      var agent = new HttpProxyAgent(proxy);
                      usvopts.agent = agent;
                    }

                    const reqest = https.request(usvopts, (response:any) => {     
                      if (response.statusCode == 200) {
                        console.log('Project [' + prjname + ']-Varialbe Group [' + vgname + '] upsert success.');
                      }
                      else {
                        console.error('Project [' + prjname + ']-Varialbe Group [' + vgname + '] upsert failure, HTTP Status Code: ' + response.statusCode);
                      }
                    }).on('error', (err: { message: any; }) => {
                      console.error('Project [' + prjname + ']-Varialbe Group [' + vgname + '] upsert failure: ' + err.message);
                    });
                    
                    reqest.write(putdata, 'utf8');
                    reqest.end(putdata, 'utf8');
                  }
                }
              }
            });
          });
        }
      }
    });
  })
}